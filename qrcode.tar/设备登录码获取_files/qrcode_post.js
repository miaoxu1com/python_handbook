
const MSG_T_INFO = 1;
const MSG_T_WARN = 2;
const MSG_T_ERR = 3;
const QR_DECODE_URL = "http://200.200.92.147/hyc/device_login/qrcode_get.php";

var in_utools = typeof utools != "undefined";

if (in_utools) {
	utools.onPluginEnter(({code, type, payload, optional}) => {
		console.log('用户进入插件', code, type, payload);
		if (code == 'identify' && type == 'img') {
			decodeFromUrl(payload);
		}
	})

}

$(document).ready(function() {
	//绑定粘贴事件 Ctrl+V
	bindPaste();
	showMsg('请将二维码截图后，粘贴到页面（Ctrl+V）', MSG_T_INFO);
});

/**
 * 设置消息
 * @param {string} msg 
 * @param {string} type 
 * @param {string} hide_timeout 
 */
function showMsg(msg, type, hide_timeout = 5)
{
	var msg_obj = $("#msg > p");
	switch(type) {
		case MSG_T_INFO:
			msg_obj.css('background-color', 'rgb(165, 243, 76)');
			break;
		case MSG_T_WARN:
			msg_obj.css('background-color', 'rgb(238, 182, 62)');
			break;
		case MSG_T_ERR:
			msg_obj.css('background-color', 'rgb(235, 61, 69)');
			break;
		default:
			msg_obj.css('background-color', 'transparent');
			break;

	}
	msg_obj.text(msg).fadeIn(1000, function() {
		if (hide_timeout != 0) {
			//hide_timeout = 0时不消失
			setTimeout(function() {
				msg_obj.fadeOut(1000);
			}, hide_timeout * 1000);//延迟5s后消失
		}
	});
}

/**
 * 设置识别结果
 * @param {string} res 
 */
function setResult(res)
{
	var qr_data_obj = $("#qrcode_str > p");
	qr_data_obj.text(res);
	res ? qr_data_obj.show() : qr_data_obj.hide();
	
}

/**
 * 识别二维码，并获取设备登录码
 * @param {string} base64Str 
 */
function decodeFromUrl(base64Str)
{
	var img_obj = $("#qrcode_img > img");
	var img_tip_obj = $("#qrcode_img > p");
	//展示图片
	img_obj.attr("src", base64Str).css('display', 'block');
	//隐藏输入文字的div
	img_tip_obj.hide();
	
	setTimeout(function() {
		var qr_ele = img_obj.get(0);
		var qr_data = jsQR_fromImageElement(qr_ele);
		if (qr_data) {
			showMsg("二维码识别成功", MSG_T_INFO);
			decodeQR(qr_data);
		} else {
			showMsg("二维码识别失败", MSG_T_WARN);
			setResult('');
		}
   }, 10);

}

/**
 * jsQR识别二维码
 * @param {htmlDom} imageElement 
 */
function jsQR_fromImageElement(imageElement)
{
	const width = imageElement.naturalWidth;
	const height = imageElement.naturalHeight;

	var canvas = document.createElement('canvas');
	var context = canvas.getContext('2d');
  
	canvas.width = width;
	canvas.height = height;
	context.drawImage(imageElement, 0, 0);
  
	var imageData = context.getImageData(0, 0, width, height);
	var qrCode = jsQR(imageData.data, imageData.width, imageData.height);//https://github.com/cozmo/jsQR
  
	return qrCode ? qrCode.data : null;

}

/**
 * 获取设备登录码
 * @param {string} qrData 
 */
function decodeQR(qrData)
{
	setResult("");

	// $.get(QR_DECODE_URL + btoa(qrData), function(data, status) {
	// 	console.log("发送：" + qrData + "\n返回: " + data + "\n状态: " + status);
	// 	if(status == 'success' && data.match("^\{(.+:.+,*){1,}\}$")) {
	// 		var rdata = jQuery.parseJSON(data);
	// 		if (rdata.success) {
	// 			showMsg("解析成功", MSG_T_INFO);
	// 			setResult(rdata.data);
	// 		} else {
	// 			showMsg("解析失败：" + rdata.msg, MSG_T_WARN);
	// 		}
	// 	} else {
	// 		showMsg("服务器错误", MSG_T_ERR);
	// 	}
	// });
	var get_url;
	if (in_utools) {
		const pluginInfo = window.pluginInfo;
		get_url = QR_DECODE_URL + "?qr=" + btoa(qrData) + "&v=" + pluginInfo.version;
	} else {
		get_url = QR_DECODE_URL + "?qr=" + btoa(qrData);
	}

	$.ajax({
		type: "GET",
		url: get_url,
		dataType: "json",
		error: function(xhr) {
			console.log("发送：" + qrData + "\n返回: 错误（" + xhr.status + "，" + xhr.statusText + "）");
			showMsg("请求错误", MSG_T_ERR);
		},
        success: function(rdata, status, xhr) {
			console.log("发送：" + qrData + "\n返回: " + JSON.stringify(rdata) + "\n状态: " + status + "/" + xhr.status);
			if(status == 'success' && 200 == xhr.status) {
				if (rdata.success) {
					setResult(rdata.data);
					if(in_utools && utools.copyText(rdata.data)) {
						showMsg("解析成功，已复制到粘贴板", MSG_T_INFO);
					} else {
						showMsg("解析成功", MSG_T_INFO);
					}
				} else {
					showMsg("解析失败：" + rdata.msg, MSG_T_WARN);
				}
			} else {
				showMsg("服务器错误", MSG_T_ERR);
			}
        }

	});
}


//绑定粘贴事件
function bindPaste(){
	//定义变量存储获取的图片内容
	var blob;
	//获取body对象
	var body = document.getElementsByTagName("body");
	//定义body标签绑定的粘贴事件处理函数
	var fun = function(e) {
		//获取clipboardData对象
		var data=e.clipboardData||window.clipboardData;
		if ( !(data && data.items[0]) ) {
			return;
		}
		//获取图片内容
		blob=data.items[0].getAsFile();
		//判断是不是图片，最好通过文件类型判断
		var isImg=(blob&&1)||-1;
		var reader=new FileReader();
		if(isImg>=0){
			//将文件读取为 DataURL
			reader.readAsDataURL(blob);
		}
		//文件读取完成时触发
		reader.onload = function(event) {
			//获取base64流
			var base64_str=event.target.result;
			decodeFromUrl(base64_str);
		}
	}
	//通过body标签绑定粘贴事件，注意有些标签绑定粘贴事件可能出错
	body[0].removeEventListener('paste', fun);
	body[0].addEventListener('paste', fun);
}
